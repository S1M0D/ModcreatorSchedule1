using System.Windows;

namespace Schedule1ModdingTool
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            
            // Application startup initialization
            // Custom theme handled by Styles.xaml
        }
    }
}